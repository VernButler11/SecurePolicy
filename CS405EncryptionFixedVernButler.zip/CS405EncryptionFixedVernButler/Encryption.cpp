#include <fstream>
#include <iostream>
#include <sstream>
#include <ctime>

std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const size_t key_length = key.length();
    const size_t source_length = source.length();

    if (key_length == 0 || source_length == 0)
        return "";

    std::string output = source;

    for (size_t i = 0; i < source_length; ++i)
        output[i] = source[i] ^ key[i % key_length];

    return output;
}

std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    std::stringstream buffer;

    if (!file)
        return "";

    buffer << file.rdbuf();
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
        return string_data.substr(0, pos);

    return "";
}

void save_data_file(const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    std::ofstream file(filename);
    if (!file)
        return;

    time_t now = time(nullptr);
    tm local_time;
    localtime_s(&local_time, &now);

    char date_buffer[11];
    std::strftime(date_buffer, sizeof(date_buffer), "%Y-%m-%d", &local_time);

    file << student_name << "\n";
    file << date_buffer << "\n";
    file << key << "\n";
    file << data;
}
